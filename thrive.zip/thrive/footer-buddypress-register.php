<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package thrive
 */

?>

<?php do_action( 'thrive_after_body' ); ?>

<?php wp_footer(); ?>

</div><!--#thrive-global-wrappe-registerr-->
</body>
</html>
