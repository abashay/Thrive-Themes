Thrive

===

Thrive is an innovative WordPress Theme designed to cater company portals, 
organisational websites, company intranet and extranets.

Thrive helps you build a WordPress based intranet for your company so that your staffs 
and members can easily share information, files, events, docs, resources, etc. 

Thrive can also be used to facilitate group projects, reports, and activities.
